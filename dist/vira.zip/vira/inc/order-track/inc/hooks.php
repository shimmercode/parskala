<?php
 // Don't call the file directly
if ( !defined( 'ABSPATH' ) ) exit;

if(!class_exists('prk_ORDER_TRACKER')) {
	return;
}

// Tracking Heading
function cbwct_order_tracking_heading(){
	echo __('Order Tracker', 'cbwet');
}
add_filter( 'cbwct_order_tracking_heading', 'cbwct_order_tracking_heading');

// Order Number
function cbwct_field_text_order_number(){
	echo __('Order Number', 'cbwet');
}
add_filter( 'cbwct_field_text_order_number', 'cbwct_field_text_order_number');



// Submit Button text
function cbwct_submit_button_text(){
	echo __('Track Order', 'cbwet');
}
add_filter( 'cbwct_submit_button_text', 'cbwct_submit_button_text');

// Order and Phone number is required
function cbwct_order_number_phone_number_required(){
	printf('%s شماره موبایل یا شناسه نامعتبر %s', '<h3 class="cbwct_notice">', '</h3>');
}
add_filter( 'cbwct_order_number_phone_number_required', 'cbwct_order_number_phone_number_required');


// set limit for showing title in tracking page
function cbwct_product_title_trim_words($value) {
	return 7;
}
add_filter('cbwct_product_title_trim_words', 'cbwct_product_title_trim_words');



function cbwct_order_is_not_found($value, $order_number) {

	$order_not_found = sprintf('%s Oops! Sorry! %s order is not found! please check order or phone number %s', '<h5 class="cbwct_notice">', $order_number, '</h5>');

	return $order_not_found;
}
add_filter('cbwct_order_is_not_found', 'cbwct_order_is_not_found', 10, 2);
